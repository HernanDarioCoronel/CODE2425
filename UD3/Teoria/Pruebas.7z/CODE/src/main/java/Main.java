import java.util.Date;

public class Main {
    public static void main(String[] args) {

      //TODO crear banco, clientes, cuentas, movimientos de saldo
    }
}